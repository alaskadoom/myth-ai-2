# 🧵 MYTH AI 2.0 — Streamlit Web App

**Profit + Design Intelligence Engine**
Inspired by the Surat Textile Industry

---

## 🚀 How to Deploy (Free — 5 Minutes)

### Step 1 — Create GitHub Account
Go to https://github.com and sign up (free)

### Step 2 — Create a New Repository
1. Click the **"+"** button → **"New repository"**
2. Name it: `myth-ai-2`
3. Set it to **Public**
4. Click **"Create repository"**

### Step 3 — Upload These 2 Files
Upload both files to your repository:
- `app.py`
- `requirements.txt`

### Step 4 — Deploy on Streamlit Cloud
1. Go to https://streamlit.io/cloud
2. Sign in with your GitHub account
3. Click **"New app"**
4. Select your repository: `myth-ai-2`
5. Main file path: `app.py`
6. Click **"Deploy!"**

### Step 5 — Get Your Link
After 2-3 minutes your app will be live at:
```
https://YOUR-USERNAME-myth-ai-2-app-XXXXX.streamlit.app
```
Share this link with anyone — works on phone and desktop!

---

## 💻 Run Locally (on your PC)

```bash
pip install streamlit numpy pandas matplotlib scikit-learn Pillow
streamlit run app.py
```

Then open http://localhost:8501 in your browser.

---

## 📦 What the App Does

| Feature | Details |
|---------|---------|
| 🎨 Design Generation | 4-layer PIL textile design engine |
| 🔁 Seamless Repeat | Tiled pattern preview (3×2 grid) |
| 🎨 Color Intelligence | Top 5 market-optimized palettes |
| 📊 Demand Prediction | RandomForest ML model (2,000 samples) |
| ⬇️ Download | Export design as PNG |
| 📱 Mobile Ready | Works on phone browser |

---

*MYTH AI 2.0 — AI-Powered · Data-Driven · Market-Optimized*
